<?php
require_once 'db_connectie.php';

// ------- functies
function genresAsSelect()
{
    $db = maakVerbinding();
    $sql = 'select *
            from stuk
            order by componistId';

    $data = $db->query($sql);

    $html = '<select id="stuk" name="stuk">';

    foreach ($data as $rij) {
        $componistid = $rij['componistid'];
        $html .= "<option value=\"$componistid\">$componistid</option>";
    }

    $html .= '</select>';
    return $html;
}

// ------- logica
if (isset($_GET['stuk'])) {
    $stuk = $_GET['stuk'];
} else {
    $stuk = 'componistid';
}

// verbinding maken met db
$db = maakVerbinding();

// Query maken
$sql = 'select *
from stuk
order by componistId';

// Gegevens ophalen
$data = $db->prepare($sql);

$data_array = [
    ':stuk' => $stuk
];

$data->execute($data_array);

// Gegevens verwerken
$muziekstukken = '<table>';
foreach ($data as $rij) {
    // Haal alle kolomen op
    $stuknr = $rij['stuknr'];
    $stuknrOrigineel = $rij['stuknrOrigineel'];
    $componistID = $componistID['$componistID'];
    $titel = $rij['titel'];
    $genrenaam = $rij['genrenaam'];
    $speelduur = $rij['speelduur'];
    $jaartal = $rij['jaartal'];
    $niveaucode = $rij['niveaucode'];

    $muziekstukken .= "<tr><td>$stuknr</td><td>$titel</td><td>$stuknrOrigineel</td><td>$genrenaam</td><td>$niveaucode</td><td>$speelduur</td><td>$jaartal</td></tr>";
}
$muziekstukken .= '<table>';

?>
<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <title>Muziekstukken</title>
</head>

<body>
    <label for="genre">Filter:</label>
    <form action="" method="get">
        <?= genresAsSelect() ?>

        <input type="submit" value="filter" />
    </form>


    <h1>Muziekstukken</h1>
    <?= $muziekstukken ?>
</body>

</html>