</main>
<footer>
    <p>&copy; <?= date('Y') ?> Pizzeria Sole Machina</p> |   <a href="privacy.php">Privacyverklaring</a>
    </p>
</footer>
</body>
</html>
