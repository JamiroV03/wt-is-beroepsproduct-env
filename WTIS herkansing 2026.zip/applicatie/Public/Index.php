<?php
require_once '../includes/header.php';
?>

<h1>Welkom bij Pizzeria Sole Machina 🍕</h1>

<p>
Bij Pizzeria Sole Machina kun je eenvoudig online je bestelling plaatsen.
Bekijk ons menu, stel je bestelling samen en volg de status.
</p>

<p>
<a href="menu.php">👉 Bekijk het menu</a>
</p>

<?php
require_once '../includes/footer.php';
